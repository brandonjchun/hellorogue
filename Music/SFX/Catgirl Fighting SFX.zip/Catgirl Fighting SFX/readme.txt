Royalty free voice clips for your fighting game, rpg, visual novel, etc.!

Credit appreciated, but not required.

Thanks for reading!

~ cicifyre
<https://cicifyre.itch.io/>