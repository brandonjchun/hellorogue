Royalty free voice clips for your visual novel, rpg, etc.!

Credit appreciated, but not required.

Thanks for reading!

~ cicifyre
<https://cicifyre.itch.io/>